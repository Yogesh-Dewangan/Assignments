function readEnvVariable() {
    console.log(`Hello ${process.env.USERNAME}`);
}

readEnvVariable();