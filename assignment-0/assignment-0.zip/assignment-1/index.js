// const imageHandler = require('./imageHandler')
// var http = require('http');
// const imageHandler = require('./imageHandler')
import imageHandler from "./imageHandler.js";

function iAmNotRoboat() {
    imageHandler()
}

iAmNotRoboat();